% Run simulation for matrix capture simulation
% i.e emit and record from every transducer array

% Edited by Megumi Hirose
% April. 15, 2025

%% set up file path
clear variables
clear global
close all hidden
clc

Laura = false;
run_sim = true; 

if Laura
    folder.base = 'C:\Users\lco137\OneDrive - University of Canterbury\Project management\Imaging Team NZ\Megumi 2025\Megumi_photoacoustic_aberration_shared_2025\Beamforming & imaging lab\megumi_code_april15';
    cd(folder.base)
    addpath([folder.base '/subfunctions']);
else
    folder.base='C:\Users\mhi70\OneDrive - University of Canterbury\Megumi_photoacoustic_aberration_shared_2025\Beamforming & imaging lab\megumi_code_april15';
    % folder.base = 'C:\Users\mhi70\OneDrive - University of Canterbury\Megumi_photoacoustic_aberration_shared_2025\Beamforming & imaging lab\megumi_code_march_18';
    cd(folder.base)
    addpath([folder.base '/subfunctions']); % or wherever the subfunctions folder is
end
set(0,'DefaultFigureWindowStyle','docked')  % jucst a preference - you can change this if you like


%% define global variables

global kgrid
global pml
global medium
global pulse


%% set up kgrid

yspan = 21e-3; % span in lateral direction [m]
xspan = 15e-3; % span depth [m]

Ny = 236; % after expansion, computational grid becomes 256 which is 2^8
dy = yspan/Ny;

Nx = 236;
dx = xspan/Nx;

kgrid = kWaveGrid(Nx, dx, Ny, dy);

% Set the Perfectly Matched Layer properties
pml.size  = 10;  % [pts] default is 20, 10 adds 20 to Nx, Ny
pml.alpha = 5;   % default is 2, but that may be too big
pml.inside = false;


%% define propagation medium properties
define_medium(Nx, dx, Ny,dy);% set base medium properties (required to define array in next section)

% homogeneous medium with acoustic wavespeed given by compressional_wavespeed_tissue.
compressional_wavespeed_tissue = 1540;   % [m/s]
density_tissue     = 910;  % [kg/m^3]

%% Add aberrating layer

ab_layer_speed = medium.sound_speed_ref*0.5;
thickness = 2e-3; %[m]
depth = 5e-5; % [m]

% convert to points
thick_pts = thickness/dx;
depth_pts = thickness/dx;

medium.sound_speed(depth_pts:depth_pts+thick_pts,:) = ab_layer_speed;

%% Add Noise
noise = wgn(Nx, Ny, 1); % white gaussian noise added
noise = (noise/max(noise(:)))*medium.sound_speed_ref*0.15; % scale noise to 15% of sound speed
medium.sound_speed = medium.sound_speed + noise;


%% Add a circular reflective target
rx = 11; % target position, depth [mm]
ry = 12; % target position, lateral direction [mm]

r = 0.45*pulse.wavelength_ref*1e3;

% target radius in multiples of wavelength [mm]
refl = 3; % reflectivity

% converting target position in mm to pts on the grid
rpts = r/dx*1e-3; %[points]
xc = rx/dx*1e-3; % center of circle x
yc = ry/dy*1e-3; % center of circle y

% placing the target into the grid

for i = 1:Nx
    for j=1:Ny
        dist = sqrt((i-xc).^2+(j-yc).^2);
        if any(dist < rpts)
            medium.sound_speed(i,j) = ...
                medium.sound_speed(i,j)*refl(dist<rpts);
        end
    end
end

%% Plot grid geometry and medium characteristics

fig1 = figure;
ax_density = subplot(1,2,1);
imagesc(kgrid.y_vec*1000,kgrid.x_vec*1000,medium.density); % plot a 2D image of the medium density
title('density');
xlabel('Lateral distance (mm)', 'Interpreter','latex','Fontsize',10)
ylabel('Depth (mm)', 'Interpreter','latex','Fontsize',10)
a = colorbar;
a.Label.String = 'kg/m^3'; % units for colorbar
axis image  % sets the aspect ratio so that equal tick mark increments on the x-,y- and z-axis are equal in size.

ax_speed = subplot(1,2,2);
imagesc(kgrid.y_vec*1000,kgrid.x_vec*1000,medium.sound_speed); % plot a 2D image of the medium sound speed
title('sound speed')
xlabel('Lateral distance (mm)', 'Interpreter','latex','Fontsize',10)
ylabel('Depth (mm)', 'Interpreter','latex','Fontsize',10)
a = colorbar;
a.Label.String = '[m/s]'; % units for colorbar
axis image


%% define source transducer array
% The structure 'array' holds all of the info on the transducer array.
%   It has a substructure 'element', which holds info in individual array elements

clear array*

[array] = define_transducer_array_2D();


%% Plot transducer array/s on the computational grid
figure(fig1);
hold(ax_density,'on')
plot(ax_density,array.element.lateral*1000,array.element.depth*1000,'wo','MarkerFaceColor','w','MarkerSize',3,'Marker','s');   % plot a line of points where the source array is
hold(ax_speed,'on')
plot(ax_speed,array.element.lateral*1000,array.element.depth*1000,'wo','MarkerFaceColor','w','MarkerSize',3,'Marker','s');   % plot a line of points where the source array is


%% define acoustic pulse for emission
define_input_pulse;

fig2 = figure;
plot(pulse.time_us,pulse.signal);
title('Input pulse - time domain');
xlabel('$t$ [$\mu$s]','Interpreter','latex');
ylabel('amplitude');

% run simulation
% for full matrix capture...

for kk=1:array.element.num % for every transducer array

    % % Choose which elements will emit
    array.element.emission = kk;

    if kk==1
        [K,array,~] = run_simulation(array,[], true);

        M = zeros(array.element.num, array.element.num, size(K,2));
    else
        [K,array,~] = run_simulation(array,[], false);
    end

    M(kk,:,:) = K;

end
save('Kuu.mat','M','array','pulse','pml','medium','kgrid','folder'); % save the dataset!



